//
//  ViewController.swift
//  ITCAMP_Training
//
//  Created by Prapawit Patthasirivichot on 26/3/2562 BE.
//  Copyright © 2562 Prapawit Patthasirivichot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

