//
//  GameViewController.swift
//  Guess Me
//
//  Created by Patcharapon Joksamut on 15/3/2562 BE.
//  Copyright © 2562 apple. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {
    
    let imageArray = [#imageLiteral(resourceName: "duck"), #imageLiteral(resourceName: "cat"), #imageLiteral(resourceName: "ant"), #imageLiteral(resourceName: "dog"), #imageLiteral(resourceName: "bee")]
    let answerArray = ["duck", "cat", "ant", "dog", "bee"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
