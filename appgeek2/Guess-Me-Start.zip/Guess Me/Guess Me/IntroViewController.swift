//
//  ViewController.swift
//  Guess Me
//
//  Created by Patcharapon Joksamut on 15/3/2562 BE.
//  Copyright © 2562 apple. All rights reserved.
//

import UIKit

class IntroViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

